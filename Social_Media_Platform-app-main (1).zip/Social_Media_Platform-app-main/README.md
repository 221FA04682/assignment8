# Social_Media_Platform-app
# mern-social-media  
This is a MERN stack Project for social media platform.  
